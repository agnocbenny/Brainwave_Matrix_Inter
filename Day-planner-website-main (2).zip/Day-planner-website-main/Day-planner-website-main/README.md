
# DAY-PLANNER

Hey! DAY-PLANNER is a website designed to help you schedule your day. 
So, get ready to plan your day with DAY-PLANNER.

Manage your work and life efficiently with DAY-PLANNER.

With DAY-PLANNER you never miss any of your meetings and any other important tasks. Write down all your work and life related tasks in an organized way with DAY-PLANNER. Get your day organized in seconds.



## Tech Stack

- Html
- Css
- JavaScript 
- JQuery


## Screenshots







## Features

- Light/dark mode toggle.
- You can add as many tasks as you need on that particular hour and delete later.

